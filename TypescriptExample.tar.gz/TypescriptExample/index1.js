var jsoArray = [];
var try_example = (function () {
    function try_example(name, lname, age, City, State, Zip, Title, Company, dropmenutab) {
        this.name = name;
        this.lname = lname;
        this.age = age;
        this.City = City;
        this.State = State;
        this.Zip = Zip;
        this.Title = Title;
        this.Company = Company;
        this.dropmenutab = dropmenutab;
        this.d = function (person) {
            var dirtyFormID = "Dtfrom";
            var resetForm = document.getElementById(dirtyFormID);
            resetForm.reset();
            var tabID = "tab";
            var createtablein = document.getElementById(tabID);
            jsoArray.push(person);
            console.log(jsoArray);
        };
    }
    return try_example;
}());
function sort(valueee) {
    //var name = abc;
    //alert("name from sort "+name);
    function compare(a, b) {
        //console.log("name"+name);
        console.log("abc-->" + valueee.toString());
        //console.log(typeof (abc));
        a.k = valueee.toString();
        console.log(a.fname);
        var genreA = a.k.toUpperCase();
        var genreB = b.k.toUpperCase();
        //alert("genreA"+genreA)
        var comparison = 0;
        if (genreA > genreB) {
            comparison = 1;
        }
        else if (genreA < genreB) {
            comparison = -1;
        }
        return comparison;
    }
    jsoArray = jsoArray.sort(compare);
    console.log(jsoArray);
}
function valRequest() {
    var d1 = document.getElementById("fname").value;
    var d2 = document.getElementById("lname").value;
    var d3 = parseInt(document.getElementById("age").value);
    var d4 = document.getElementById("City").value;
    var d5 = document.getElementById("State").value;
    var d6 = parseInt(document.getElementById("Zip").value);
    var d7 = document.getElementById("Title").value;
    var d8 = document.getElementById("Company").value;
    var d9 = document.getElementById("dropmenutab").value;
    var mr = new try_example(d1, d2, d3, d4, d5, d6, d7, d8, d9);
    alert("from valRequest");
    mr.d(mr);
}
