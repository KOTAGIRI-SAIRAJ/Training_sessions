/**
 * Created by semanticbit on 5/5/17.
 */
interface ICar {
    name: string;
    lname: string;
    age: number;
    City: string;
    State: string;
    Zip: number;
    Title: string;
    Company: string;
    dropmenutab : string;

}
var jsoArray=[] ;
class try_example implements ICar{

    constructor(public name,public lname,public age,public City,public State,public Zip,public Title,public Company,public dropmenutab) {


    }

    d = (person : ICar) : void =>{
        var dirtyFormID = "Dtfrom";
        var resetForm = <HTMLFormElement>document.getElementById(dirtyFormID);
        resetForm.reset();
        var tabID = "tab";
        var createtablein = <HTMLFormElement>document.getElementById(tabID );

        jsoArray.push(person);
        console.log(jsoArray)

    }
}
function sort(valueee:any) {
    //var name = abc;

    //alert("name from sort "+name);
    function compare(a, b) {
        //console.log("name"+name);
        console.log("abc-->"+valueee.toString());
        //console.log(typeof (abc));
        a.k = valueee.toString();
        console.log(a.fname);
        const genreA = a.k.toUpperCase();
        const genreB = b.k.toUpperCase();
        //alert("genreA"+genreA)
        var comparison = 0;
        if (genreA > genreB) {
            comparison = 1;
        } else if (genreA < genreB) {
            comparison = -1;
        }
        return comparison;
    }
    jsoArray = jsoArray.sort(compare)
    console.log(jsoArray)


}
function valRequest() {
    var d1 = (<HTMLInputElement>document.getElementById("fname")).value;
    var d2 = (<HTMLInputElement>document.getElementById("lname")).value;
    var d3 = parseInt((<HTMLInputElement>document.getElementById("age")).value);
    var d4 = (<HTMLInputElement>document.getElementById("City")).value;
    var d5 = (<HTMLInputElement>document.getElementById("State")).value;
    var d6 = parseInt((<HTMLInputElement>document.getElementById("Zip")).value);
    var d7 = (<HTMLInputElement>document.getElementById("Title")).value;
    var d8 = (<HTMLInputElement>document.getElementById("Company")).value;
    var d9 = (<HTMLInputElement>document.getElementById("dropmenutab")).value;
    var mr = new try_example(d1,d2,d3,d4,d5,d6,d7,d8,d9);
    alert("from valRequest")
    mr.d(mr);

}

